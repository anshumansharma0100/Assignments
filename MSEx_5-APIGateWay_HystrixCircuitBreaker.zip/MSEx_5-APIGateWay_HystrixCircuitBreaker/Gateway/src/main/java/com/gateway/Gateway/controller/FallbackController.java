package com.gateway.Gateway.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class FallbackController {

    /*
    @RequestMapping("/employeeFallBack")
    public Mono<String> employeeServiceFallBack()
    {
        return Mono.just("Employee service is taking too long to respond or is down. Please try again later.");
    }

    @RequestMapping("/employeeInfoFallBack")
    public Mono<String> employeeInfoServiceFallBack()
    {
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
        return Mono.just("Employee-Info service is taking too long to respond or is down. Please try again later.");
    }

    @RequestMapping("/departmentInfoFallBack")
    public Mono<String> departmentInfoServiceFallBack()
    {
        return Mono.just("Department-Info service is taking too long to respond or is down. Please try again later.");
    }
    */
}
