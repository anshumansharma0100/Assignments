package com.employees_info_service.employeeinfoservice.record;

import com.employees_info_service.employeeinfoservice.entity.Dept;
import com.employees_info_service.employeeinfoservice.entity.Employee_Info;

public class EmployeementData
{

    private Employee_Info employee_info;
    private Dept dept;

    public EmployeementData() {
    }

    public EmployeementData(Employee_Info employee_info, Dept dept) {
        this.employee_info = employee_info;
        this.dept = dept;
    }

    public Employee_Info getEmployee_info() {
        return employee_info;
    }

    public void setEmployee_info(Employee_Info employee_info) {
        this.employee_info = employee_info;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "EmployeementData{" +
                "employee_info=" + employee_info +
                ", dept=" + dept +
                '}';
    }
}
