package com.employees_info_service.employeeinfoservice.controller;

import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.record.EmployeementData;
import com.employees_info_service.employeeinfoservice.service.EmployeeInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employeeInfo")
public class EmployeeInfoServiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeInfoServiceController.class);

    @Autowired
    EmployeeInfoService employeeInfoService;


    @RequestMapping("/{empId}")
    public Employee_Info getEmploymentInfo(@PathVariable("empId") int empId)
    {
        LOGGER.info("----- Employee Info Service Controller by empId :: " + empId);
        return employeeInfoService.getEmploymentInfo(empId);
    }

    @GetMapping("/comp/{empId}/{deptId}")
    public EmployeementData getEmploymentData(@PathVariable int empId, @PathVariable int deptId)
    {
        LOGGER.info("----- Employee Info Service Controller(EmploymentData) by empId :: " + deptId);
        return employeeInfoService.getEmploymentData(empId, deptId);
    }
}