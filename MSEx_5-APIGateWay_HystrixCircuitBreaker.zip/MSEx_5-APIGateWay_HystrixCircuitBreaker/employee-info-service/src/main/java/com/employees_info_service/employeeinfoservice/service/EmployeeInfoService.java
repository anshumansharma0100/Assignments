package com.employees_info_service.employeeinfoservice.service;

import com.employees_info_service.employeeinfoservice.client.DepartmentDetailsClient;
import com.employees_info_service.employeeinfoservice.entity.Dept;
import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.record.EmployeementData;
import com.employees_info_service.employeeinfoservice.repository.EmployeeInfoRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeInfoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeInfoService.class);

    @Autowired
    EmployeeInfoRepository employeeInfoRepository;

    @Autowired
    private DepartmentDetailsClient deptInfoClient;

    public Employee_Info getEmploymentInfo(int empId) {
        Employee_Info employee_info = employeeInfoRepository.findById(empId).get();
        LOGGER.info("Employee Info :: " + employee_info);

        return employee_info;
    }

    @HystrixCommand(fallbackMethod = "fallbackGetEmploymentData")
    public EmployeementData getEmploymentData(int empId, int deptId) {
        Employee_Info employee_info = employeeInfoRepository.findById(empId).get();
        LOGGER.info("Employee Info :: " + employee_info);

        Dept dept = deptInfoClient.getDetaptmentDetails(deptId);
        LOGGER.info("***** Dept Class :: " + dept.toString());

        return new EmployeementData(employee_info, dept);
    }

    private EmployeementData fallbackGetEmploymentData(int empId, int deptId)
    {
        LOGGER.info("EmploymentData for empId : " + empId + ", deptId : " + deptId + " not found.");
        return new EmployeementData(new Employee_Info(0, "", "", 0, 0), new Dept(0, "", ""));
    }
}
