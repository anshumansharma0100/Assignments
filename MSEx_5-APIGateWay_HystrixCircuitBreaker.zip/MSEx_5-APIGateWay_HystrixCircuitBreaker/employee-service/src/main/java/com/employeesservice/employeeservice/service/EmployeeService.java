package com.employeesservice.employeeservice.service;

import com.employeesservice.employeeservice.client.DepartmentDetailsClient;
import com.employeesservice.employeeservice.client.EmployeeInfoServiceClient;
import com.employeesservice.employeeservice.entity.Dept;
import com.employeesservice.employeeservice.entity.Employee;
import com.employeesservice.employeeservice.entity.Employee_Info;
import com.employeesservice.employeeservice.record.EmployeementData;
import com.employeesservice.employeeservice.repository.EmployeeServiceRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);

    @Autowired
    private EmployeeInfoServiceClient employeeInfoClient;

    @Autowired
    private DepartmentDetailsClient deptInfoClient;

    @Autowired
    EmployeeServiceRepository empRepository;

    @HystrixCommand(fallbackMethod = "fallbackGetEmployeeInfo")
    public Employee_Info getEmployee(int employeeId)
    {
        LOGGER.info("***** EmployeeService Class");
        Employee employee = empRepository.findByEmpid(employeeId).get();
        LOGGER.info("***** Employee Class :: " + employee.toString());

        Employee_Info employee_info = employeeInfoClient.getEmploymentInfo(employeeId);
        LOGGER.info("***** EmployeeInfo Class :: " + employee_info.toString());

        return employee_info;
    }

    @HystrixCommand(fallbackMethod = "fallbackGetDepartment")
    public Dept getDeptDetails(int deptId)
    {
        LOGGER.info("***** EmployeeService Class");

        Employee employee = empRepository.findByDeptid(deptId).get();
        LOGGER.info("***** Employee Class :: " + employee.toString());

        Dept dept = deptInfoClient.getDetaptmentDetails(deptId);
        LOGGER.info("***** Dept Class :: " + dept.toString());

        return dept;
    }

    @HystrixCommand(fallbackMethod = "fallbackGetEmploymentData")
    public EmployeementData getDetails(int empId)
    {
        LOGGER.info("***** EmployeeService Class");

        Employee employee = empRepository.findByEmpid(empId).get();
        LOGGER.info("***** Employee Class :: " + employee.toString());

        EmployeementData employeementData = employeeInfoClient.getEmploymentData(employee.getEmpid(), employee.getDeptid());
        LOGGER.info("***** EmploymentData Class :: " + employeementData.toString());

        return employeementData;
    }

    @HystrixCommand(fallbackMethod = "fallbackGetEmploymentData")
    public EmployeementData getEachDetails(int empId)
    {
        LOGGER.info("***** EmployeeService Class");

        Employee employee = empRepository.findByEmpid(empId).get();
        LOGGER.info("***** Employee Class :: " + employee.toString());

        Employee_Info employee_info = new Employee_Info(111,"Anshuman","a@abc.com",01010,11100);//employeeInfoClient.getEmploymentInfo(employee.getEmpid());
        LOGGER.info("***** EmploymentData Class :: " + employee_info.toString());

        Dept dept = deptInfoClient.getDetaptmentDetails(employee.getDeptid());
        LOGGER.info("***** Dept Class :: " + dept.toString());

        return new EmployeementData(employee_info, dept);
    }

    private Employee_Info fallbackGetEmployeeInfo(int empId)
    {
        LOGGER.info("EmployeeInfo not for for empId : " + empId + " not found. Employee-Info-Service is down/not working.");
        return new Employee_Info(0, "", "", 0, 0);
    }

    private Dept fallbackGetDepartment(int deptId)
    {
        LOGGER.info("Department Id : " + deptId + " not found. Department-Info-Service is down/not working.");
        return new Dept(0, "", "");
    }

    private EmployeementData fallbackGetEmploymentData(int empId)
    {
        LOGGER.info("EmploymentData for empId : " + empId + " not found.");
        return new EmployeementData(new Employee_Info(0, "", "", 0, 0), new Dept(0, "", ""));
    }

}
