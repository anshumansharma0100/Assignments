package com.employeesservice.employeeservice.client;

import com.employeesservice.employeeservice.entity.Dept;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(url="localhost:8083", name="Department-Info-Service")
@FeignClient("Department-Info-Service")
public interface DepartmentDetailsClient {

    @GetMapping("/department/{deptid}")
    public Dept getDetaptmentDetails(@PathVariable("deptid") int deptId);

}
