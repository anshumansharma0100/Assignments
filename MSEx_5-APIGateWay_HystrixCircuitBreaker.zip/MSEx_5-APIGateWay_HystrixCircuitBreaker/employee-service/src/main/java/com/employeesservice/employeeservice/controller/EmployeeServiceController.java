package com.employeesservice.employeeservice.controller;

import com.employeesservice.employeeservice.entity.Dept;
import com.employeesservice.employeeservice.entity.Employee_Info;
import com.employeesservice.employeeservice.record.EmployeementData;
import com.employeesservice.employeeservice.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeServiceController {

    private  static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceController.class);

    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/empInfo/{employeeId}")
    public Employee_Info getEmployee(@PathVariable int employeeId) {
        LOGGER.info("***** Calling getEmployee() for employee id :: " + employeeId);
        return employeeService.getEmployee(employeeId);
    }

    @RequestMapping("/dept/{deptId}")
    public Dept getDeptDetails(@PathVariable int deptId) {
        LOGGER.info("***** Calling getDeptDetails() for dept id :: " + deptId);
        return employeeService.getDeptDetails(deptId);
    }

    @RequestMapping("/nested/{empId}")
    public EmployeementData getDetails(@PathVariable int empId) {
        LOGGER.info("***** Calling getDetails() for employee id :: " + empId);
        return employeeService.getDetails(empId);
    }

    @RequestMapping("/{empId}")
    public EmployeementData getEachDetails(@PathVariable int empId) {
        LOGGER.info("***** Calling getDetails() for employee id :: " + empId);
        return employeeService.getEachDetails(empId);
    }
}
