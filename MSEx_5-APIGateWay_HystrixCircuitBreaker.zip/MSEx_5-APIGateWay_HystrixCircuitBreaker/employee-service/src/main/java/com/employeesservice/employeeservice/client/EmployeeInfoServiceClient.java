package com.employeesservice.employeeservice.client;

import com.employeesservice.employeeservice.entity.Employee_Info;
import com.employeesservice.employeeservice.record.EmployeementData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(url="localhost:8082", name="Employee-Info-Service")
@FeignClient(value = "Employee-Info-Service")
public interface EmployeeInfoServiceClient {

    @GetMapping("/employeeInfo/{empId}")
    public Employee_Info getEmploymentInfo(int empId);

    @GetMapping("/employeeInfo/comp/{empId}/{deptId}")
    public EmployeementData getEmploymentData(@PathVariable int empId,@PathVariable int deptId);

}