package com.springbootcrud.SpringbootCRUD.Controller;

import com.springbootcrud.SpringbootCRUD.Entities.Employee_Info;
import com.springbootcrud.SpringbootCRUD.Services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employee")
public class WelcomeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping("/addEmployee")
    void addEmployee(@RequestBody Employee_Info employee) {
        System.out.println("Employee added : "+ employeeService.addEmployee(employee).toString());
    }

    @GetMapping("/getEmployee/{id}")
    void getEmployee(@PathVariable("id") int id) {
        System.out.println("Employee detail found : "+ employeeService.getEmployee(id).toString());
    }

    @GetMapping("/getAllEmployee")
    void getAllEmployee() {
        Iterable<Employee_Info> itr = employeeService.getAllEmployee();
        itr.forEach(System.out::println) ;
    }

    @PutMapping("/updateEmployee")
    void updateEmployee(@RequestBody Employee_Info employee) {
        System.out.println("Employee detail updated : "+ employeeService.updateEmployee(employee).toString());
    }

    @DeleteMapping("/delete/{id}")
    void deleteEmployee(@PathVariable int id)
    {
        employeeService.deleteEmployee(id);
    }
}
