package com.springbootcrud.SpringbootCRUD.Repository;

import com.springbootcrud.SpringbootCRUD.Entities.Employee_Info;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee_Info, Integer> {

    Employee_Info findByName(String name);
}
