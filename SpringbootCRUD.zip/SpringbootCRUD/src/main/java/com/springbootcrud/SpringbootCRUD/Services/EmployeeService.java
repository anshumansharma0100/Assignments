package com.springbootcrud.SpringbootCRUD.Services;

import com.springbootcrud.SpringbootCRUD.Entities.Employee_Info;
import com.springbootcrud.SpringbootCRUD.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployeeService
{
    @Autowired
    EmployeeRepository employeeRepository;

    public Employee_Info addEmployee(Employee_Info employee){
         return employeeRepository.save(employee);
    }
    public Optional<Employee_Info> getEmployee(int id){
        return employeeRepository.findById(id);
    }
    public Iterable<Employee_Info> getAllEmployee(){
       return employeeRepository.findAll();
    }
    public Employee_Info updateEmployee(Employee_Info employee){
        return employeeRepository.save(employee);
    }
    public void deleteEmployee(int id) {
        employeeRepository.deleteById(id);
    }
}
