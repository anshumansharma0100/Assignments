package com.kafkapublisher.KafkaPublisher.controller;

import com.kafkapublisher.KafkaPublisher.User;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableKafka
public class KafkaConsumerController {
    User empDataFromTopic = null;

    @KafkaListener(groupId = "jsonemployeedata", topics = "employeedata", containerFactory = "empKafkaListenerContainerFactory")
    public User getJSONMsgFromTopic(User data)
    {
        empDataFromTopic = data;
        System.out.println("********************************" + empDataFromTopic);
        return empDataFromTopic;
    }

    /* For testing */
    @GetMapping("/consumeJSONMessage")
    public User consumeJSONMsg()
    {
        return empDataFromTopic;
    }
    /******************************************/
}
