package com.kafkapublisher.KafkaPublisher;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
@RestController
public class KafkaPublisherApplication {

	@Autowired
	private KafkaTemplate<String, Object> template;

	private String topic = "employeedata";

	@RequestMapping("/user")
	public User getEmployee()
	{

		/********************Kafka*******************
		 // It wil return default string data,
		 LOGGER.info("***** Publishing String data using kafka.");
		 template.send(topic, "Hello Sending employment data.");
		 /********************************************/

		/********************Kafka*******************/
		// To share the json object we need to configure keySerializer, valueSerializer, bootstrap server.
		System.out.println("***** Publishing JSON data using kafka.");
		User e = new User("Anshuman", 25, "Rajasthan");
		template.send(topic, e);
		/********************************************/

		return e;
	}

	public static void main(String[] args) {
		SpringApplication.run(KafkaPublisherApplication.class, args);
	}

}
