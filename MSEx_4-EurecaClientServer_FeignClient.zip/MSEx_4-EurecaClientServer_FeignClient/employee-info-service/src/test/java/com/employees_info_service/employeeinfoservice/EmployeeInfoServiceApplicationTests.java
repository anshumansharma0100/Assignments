package com.employees_info_service.employeeinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
