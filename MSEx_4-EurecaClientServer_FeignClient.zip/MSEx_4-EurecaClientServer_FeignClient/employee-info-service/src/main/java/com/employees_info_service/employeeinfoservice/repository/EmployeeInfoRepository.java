package com.employees_info_service.employeeinfoservice.repository;

import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeInfoRepository extends CrudRepository<Employee_Info, Integer> {

}
