package com.department_info_service.departmentinfoservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Dept {

    @Id
    private int dept_id;
    private String department_name;
    private String department_type;

    public int getDept_id() {
        return dept_id;
    }

    public void setDept_id(int dept_id) {
        this.dept_id = dept_id;
    }

    public String getDepartment_name() {
        return department_name;
    }

    public void setDepartment_name(String department_name) {
        this.department_name = department_name;
    }

    public String getDepartment_type() {
        return department_type;
    }

    public void setDepartment_type(String department_type) {
        this.department_type = department_type;
    }

    @Override
    public String toString() {
        return "Dept{" +
                "dept_id=" + dept_id +
                ", department_name='" + department_name + '\'' +
                ", department_type='" + department_type + '\'' +
                '}';
    }
}
