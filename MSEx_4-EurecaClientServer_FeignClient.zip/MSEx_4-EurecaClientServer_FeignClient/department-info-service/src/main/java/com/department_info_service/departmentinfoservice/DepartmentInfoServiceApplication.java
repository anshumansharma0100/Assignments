package com.department_info_service.departmentinfoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentInfoServiceApplication.class, args);
	}

}
