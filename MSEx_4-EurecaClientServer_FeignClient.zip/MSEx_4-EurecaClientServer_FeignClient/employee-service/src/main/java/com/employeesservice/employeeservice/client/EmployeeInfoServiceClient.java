package com.employeesservice.employeeservice.client;

import com.employeesservice.employeeservice.record.EmployeementData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(url="localhost:8082", name="Employee-Info-Service")
@FeignClient("Employee-Info-Service")
public interface EmployeeInfoServiceClient {

    @GetMapping("/employeeInfo/{empid}/{deptid}")
    public EmployeementData getEmployeementData(@PathVariable("empid") int empid, @PathVariable("deptid") int deptid);

}