package com.employeesservice.employeeservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee_Info {

    @Id
    private int emp_id;
    private String name;
    private String email;
    private long contact_no;
    private int salary;

    public int getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(int emp_id) {
        this.emp_id = emp_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getContact_no() {
        return contact_no;
    }

    public void setContact_no(long contact_no) {
        this.contact_no = contact_no;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee_Info{" +
                "emp_id=" + emp_id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", contact_no=" + contact_no +
                ", salary=" + salary +
                '}';
    }
}
