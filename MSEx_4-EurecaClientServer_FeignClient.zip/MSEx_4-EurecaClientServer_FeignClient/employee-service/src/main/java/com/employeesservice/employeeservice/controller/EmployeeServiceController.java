package com.employeesservice.employeeservice.controller;

import com.employeesservice.employeeservice.entity.Employee;
import com.employeesservice.employeeservice.record.EmployeementData;
import com.employeesservice.employeeservice.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employee")
public class EmployeeServiceController {

    private  static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceController.class);

    @Autowired
    EmployeeService employeeService;

    @RequestMapping({"/",""})
    public List<EmployeementData> getEmployee()
    {
        LOGGER.info("***** Calling Employee Data");
        return employeeService.getEmployee();
    }

    @RequestMapping("/{employeeId}")
    public Optional<Employee> getEmployee(@PathVariable int employeeId) {
        LOGGER.info("***** Calling Employee Data for employee id :: " + employeeId);
        return employeeService.getEmployee(employeeId);
    }

}
