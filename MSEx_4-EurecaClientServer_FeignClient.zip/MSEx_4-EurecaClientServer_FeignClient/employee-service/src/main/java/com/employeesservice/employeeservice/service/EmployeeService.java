package com.employeesservice.employeeservice.service;

import com.employeesservice.employeeservice.client.EmployeeInfoServiceClient;
import com.employeesservice.employeeservice.controller.EmployeeServiceController;
import com.employeesservice.employeeservice.entity.Dept;
import com.employeesservice.employeeservice.entity.Employee;
import com.employeesservice.employeeservice.entity.Employee_Info;
import com.employeesservice.employeeservice.record.EmployeementData;
import com.employeesservice.employeeservice.repository.EmployeeServiceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);

    @Autowired
    private EmployeeInfoServiceClient client;

    @Autowired
    EmployeeServiceRepository empRepository;

    @Autowired
    RestTemplate restTemplate;

    public List<EmployeementData> getEmployee() {

        List<Employee> employees = new ArrayList<>();
        empRepository.findAll().forEach(n->employees.add(n));

        LOGGER.info("***** EmployeeService Class");
        return employees.stream().map(employee ->
        {
            LOGGER.info("***** Calling Fiegn client here.");
            EmployeementData employeementData = client.getEmployeementData(employee.getEmpid(), employee.getDeptid());
            LOGGER.info("***** Employeement Data :: " + employeementData);

            return employeementData;
        }).collect(Collectors.toList());
    }
    public Optional<Employee> getEmployee(int employeeId) {
        return empRepository.findByEmpid(employeeId);
    }
}
