package com.department_info_service.departmentinfoservice.controller;

import com.department_info_service.departmentinfoservice.entity.Dept;
import com.department_info_service.departmentinfoservice.service.DepartmentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/department")
public class DepartmentInfoController {

    @Autowired
    DepartmentInfoService departmentInfoService;

    @RequestMapping("/{id}")
    public Optional<Dept> getDepartmentDetails(@PathVariable("id") int id)
    {
        return departmentInfoService.getDepartmentDetails(id);
    }

    @RequestMapping({"/",""})
    public Iterable<Dept> getDepartmentDetails()
    {
        return departmentInfoService.getDepartmentDetails();
    }
}
