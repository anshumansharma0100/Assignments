package com.department_info_service.departmentinfoservice.service;

import com.department_info_service.departmentinfoservice.entity.Dept;
import com.department_info_service.departmentinfoservice.repository.DepartmentInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DepartmentInfoService {

    @Autowired
    DepartmentInfoRepository departmentInfoRepository;

    public Optional<Dept> getDepartmentDetails(int id) {
        return departmentInfoRepository.findById(id);
    }

    public Iterable<Dept> getDepartmentDetails() {
        return departmentInfoRepository.findAll();
    }
}
