package com.department_info_service.departmentinfoservice.repository;

import com.department_info_service.departmentinfoservice.entity.Dept;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentInfoRepository extends CrudRepository<Dept, Integer> {

}
