package com.employees_info_service.employeeinfoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeInfoServiceApplication.class, args);
	}

}
