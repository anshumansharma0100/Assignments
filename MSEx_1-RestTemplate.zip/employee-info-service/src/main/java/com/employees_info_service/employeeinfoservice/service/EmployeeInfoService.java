package com.employees_info_service.employeeinfoservice.service;

import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.repository.EmployeeInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployeeInfoService {

    @Autowired
    EmployeeInfoRepository employeeInfoRepository;

    public Optional<Employee_Info> getEmployeeDetails(int empId) {
        return employeeInfoRepository.findById(empId);
    }

    public Iterable<Employee_Info> getEmployeeDetails() {
        return employeeInfoRepository.findAll();
    }
}
