package com.employees_info_service.employeeinfoservice.controller;

import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.service.EmployeeInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/employeeInfo")
public class EmployeeInfoServiceController {

    @Autowired
    EmployeeInfoService employeeInfoService;

    @RequestMapping({"/",""})
    public Iterable<Employee_Info> getEmployeeInfo()
    {
        return employeeInfoService.getEmployeeDetails();
    }

    @RequestMapping("/{empId}")
    public Optional<Employee_Info> getEmployeeInfo(@PathVariable("empId") int empId)
    {
        return employeeInfoService.getEmployeeDetails(empId);
    }
}
