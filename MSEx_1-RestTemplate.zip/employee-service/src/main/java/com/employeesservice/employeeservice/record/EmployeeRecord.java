package com.employeesservice.employeeservice.record;

import com.employeesservice.employeeservice.entity.Dept;
import com.employeesservice.employeeservice.entity.Employee_Info;

public class EmployeeRecord {

    private int id;
    private Employee_Info employeeInfo;
    private Dept dept;

    public EmployeeRecord(int id, Employee_Info employeeInfo, Dept dept) {
        this.id = id;
        this.employeeInfo = employeeInfo;
        this.dept = dept;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Employee_Info getEmployeeInfo() {
        return employeeInfo;
    }

    public void setEmployeeInfo(Employee_Info employeeInfo) {
        this.employeeInfo = employeeInfo;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "EmployeeRecord{" +
                "id=" + id +
                ", employeeInfo=" + employeeInfo +
                ", dept=" + dept +
                '}';
    }
}
