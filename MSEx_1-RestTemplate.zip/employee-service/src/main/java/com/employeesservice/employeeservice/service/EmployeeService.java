package com.employeesservice.employeeservice.service;

import com.employeesservice.employeeservice.entity.Employee;
import com.employeesservice.employeeservice.repository.EmployeeServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    EmployeeServiceRepository empRepository;

    public List<Employee> getEmployee() {
        List<Employee> employees = new ArrayList<>();
        empRepository.findAll().forEach(n->employees.add(n));
        return employees;
    }
    public Optional<Employee> getEmployee(int employeeId) {
        return empRepository.findByEmpid(employeeId);
    }
}
