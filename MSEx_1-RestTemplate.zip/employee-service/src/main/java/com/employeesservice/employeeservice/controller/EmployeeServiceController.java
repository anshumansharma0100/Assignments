package com.employeesservice.employeeservice.controller;

import com.employeesservice.employeeservice.entity.Dept;
import com.employeesservice.employeeservice.entity.Employee;
import com.employeesservice.employeeservice.entity.Employee_Info;
import com.employeesservice.employeeservice.record.EmployeeRecord;
import com.employeesservice.employeeservice.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@RestController
@RequestMapping("/employee")
public class EmployeeServiceController {

    @Autowired
    EmployeeService employeeService;

    @RequestMapping({"/",""})
    public List<EmployeeRecord> getEmployee()
    {
        RestTemplate restTemplate = new RestTemplate();
        List<Employee> employees = employeeService.getEmployee();
        return employees.stream().map(employee ->
        {
            Employee_Info employee_info = restTemplate.getForObject("http://localhost:8082/employeeInfo/"+employee.getEmpid(), Employee_Info.class);

            Dept dept = restTemplate.getForObject("http://localhost:8083/department/"+employee.getDeptid(), Dept.class);
            return new EmployeeRecord(employee.getId(), employee_info, dept);
        }).collect(Collectors.toList());
    }

    @RequestMapping("/{employeeId}")
    public Optional<Employee> getEmployee(@PathVariable int employeeId){
        return employeeService.getEmployee(employeeId);
    }

}
