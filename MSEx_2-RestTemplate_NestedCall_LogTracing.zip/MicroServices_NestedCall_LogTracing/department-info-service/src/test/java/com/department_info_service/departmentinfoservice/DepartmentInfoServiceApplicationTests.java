package com.department_info_service.departmentinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
