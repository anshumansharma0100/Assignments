package com.department_info_service.departmentinfoservice.service;

import com.department_info_service.departmentinfoservice.controller.DepartmentInfoController;
import com.department_info_service.departmentinfoservice.entity.Dept;
import com.department_info_service.departmentinfoservice.repository.DepartmentInfoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DepartmentInfoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentInfoService.class);

    @Autowired
    DepartmentInfoRepository departmentInfoRepository;

    public Optional<Dept> getDepartmentDetails(int id) {
        LOGGER.info("@@@@@ Fetching Department details by Id.");
        return departmentInfoRepository.findById(id);
    }

    public Iterable<Dept> getDepartmentDetails() {
        LOGGER.info("@@@@@ Fetching Department details.");
        return departmentInfoRepository.findAll();
    }
}
