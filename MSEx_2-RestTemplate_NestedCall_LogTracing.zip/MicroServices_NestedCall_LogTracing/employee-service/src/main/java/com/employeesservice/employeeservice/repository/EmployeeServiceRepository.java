package com.employeesservice.employeeservice.repository;

import com.employeesservice.employeeservice.entity.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployeeServiceRepository extends CrudRepository<Employee, Integer> {

    Optional<Employee> findByEmpid(int employeeId);

}
