package com.employees_info_service.employeeinfoservice.controller;

import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.record.EmployeementData;
import com.employees_info_service.employeeinfoservice.service.EmployeeInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/employeeInfo")
public class EmployeeInfoServiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeInfoServiceController.class);

    @Autowired
    EmployeeInfoService employeeInfoService;

    @RequestMapping({"/",""})
    public Iterable<Employee_Info> getEmployeeInfo()
    {
        LOGGER.info("----- Employee Info Service Controller.");
        return employeeInfoService.getEmployeeDetails();
    }

    @RequestMapping("/{empId}/{deptId}")
    public EmployeementData getEmployeeInfo(@PathVariable("empId") int empId, @PathVariable("deptId") int deptId)
    {
        LOGGER.info("----- Employee Info Service Controller by empId & deptId :: " + empId + "/" + deptId);
        return employeeInfoService.getEmployeeDetails(empId, deptId);
    }
}