package com.employees_info_service.employeeinfoservice.service;

import com.employees_info_service.employeeinfoservice.controller.EmployeeInfoServiceController;
import com.employees_info_service.employeeinfoservice.entity.Dept;
import com.employees_info_service.employeeinfoservice.entity.Employee_Info;
import com.employees_info_service.employeeinfoservice.record.EmployeementData;
import com.employees_info_service.employeeinfoservice.repository.EmployeeInfoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class EmployeeInfoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeInfoService.class);

    @Autowired
    EmployeeInfoRepository employeeInfoRepository;

    @Autowired
    RestTemplate restTemplate;

    public EmployeementData getEmployeeDetails(int empId, int deptId) {

        Employee_Info employee_info = employeeInfoRepository.findById(empId).get();
        LOGGER.info("----- Employee Info :: " + employee_info);

        Dept dept = restTemplate.getForObject("http://localhost:8083/department/" + deptId, Dept.class);
        LOGGER.info("----- Dept :: " + dept);

        return new EmployeementData(employee_info, dept);
    }

    public Iterable<Employee_Info> getEmployeeDetails() {
        return employeeInfoRepository.findAll();
    }
}
